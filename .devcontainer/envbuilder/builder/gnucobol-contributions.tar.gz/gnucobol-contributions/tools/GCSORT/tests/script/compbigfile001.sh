cd ../script
./compile_single.sh genbigfile
./compile_single.sh sbig001
./compile_single.sh diffile2
./compile_single.sh viewfile
