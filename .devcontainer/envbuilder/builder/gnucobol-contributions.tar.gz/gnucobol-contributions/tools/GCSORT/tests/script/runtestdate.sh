##::
../bin/gcsort SORT FIELDS=(10,8,Y2T,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2T8.srt  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(19,4,Y2T,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2T4.srt  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(24,2,Y2T,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2T2.srt  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(27,3,Y2T,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2T3.srt  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(31,5,Y2T,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2T5.srt  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(37,6,Y2T,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2T6.srt  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(44,7,Y4T,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y4T7.srt  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(52,1,Y2B,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2B.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(54,2,Y2C,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2C.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(57,1,Y2D,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2D.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(59,2,Y2P,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2P.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(62,2,Y2S,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2S.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(65,3,Y2U,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2U.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(69,4,Y2V,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2V.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(74,3,Y2X,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2X.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(74,3,Y2X,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2X.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(78,4,Y2Y,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2Y.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort SORT FIELDS=(83,2,Y2Z,A)   USE ../files/FDate.dat   RECORD F,85 ORG SQ  GIVE ../files/FDate.dat.Y2Z.srt   RECORD F,85 ORG SQ    OPTION Y2PAST=70


export dd_infile=../files/FDate.dat.Y2T8.srt
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2T4.srt 
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2T2.srt 
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2T3.srt 
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2T5.srt 
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2T6.srt 
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y4T7.srt 
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2B.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2C.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2D.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2P.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2S.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2U.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2V.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2X.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2X.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2Y.srt  
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2Z.srt  
../bin/checkfdate

##:: Merge
../bin/gcsort MERGE FIELDS=(10,8,Y2T,A)   USE ../files/FDate.dat.Y2T8.srt   RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2T8.srt   RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2T8.mrg  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(19,4,Y2T,A)   USE ../files/FDate.dat.Y2T4.srt   RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2T4.srt   RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2T4.mrg  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(24,2,Y2T,A)   USE ../files/FDate.dat.Y2T2.srt   RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2T2.srt   RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2T2.mrg  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(27,3,Y2T,A)   USE ../files/FDate.dat.Y2T3.srt   RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2T3.srt   RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2T3.mrg  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(31,5,Y2T,A)   USE ../files/FDate.dat.Y2T5.srt   RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2T5.srt   RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2T5.mrg  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(37,6,Y2T,A)   USE ../files/FDate.dat.Y2T6.srt   RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2T6.srt   RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2T6.mrg  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(44,7,Y4T,A)   USE ../files/FDate.dat.Y4T7.srt   RECORD F,85 ORG SQ USE ../files/FDate.dat.Y4T7.srt   RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y4T7.mrg  RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(52,1,Y2B,A)   USE ../files/FDate.dat.Y2B.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2B.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2B.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(54,2,Y2C,A)   USE ../files/FDate.dat.Y2C.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2C.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2C.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(57,1,Y2D,A)   USE ../files/FDate.dat.Y2D.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2D.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2D.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(59,2,Y2P,A)   USE ../files/FDate.dat.Y2P.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2P.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2P.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(62,2,Y2S,A)   USE ../files/FDate.dat.Y2S.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2S.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2S.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(65,3,Y2U,A)   USE ../files/FDate.dat.Y2U.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2U.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2U.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(69,4,Y2V,A)   USE ../files/FDate.dat.Y2V.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2V.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2V.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(74,3,Y2X,A)   USE ../files/FDate.dat.Y2X.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2X.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2X.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(74,3,Y2X,A)   USE ../files/FDate.dat.Y2X.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2X.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2X.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(78,4,Y2Y,A)   USE ../files/FDate.dat.Y2Y.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2Y.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2Y.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70
../bin/gcsort MERGE FIELDS=(83,2,Y2Z,A)   USE ../files/FDate.dat.Y2Z.srt    RECORD F,85 ORG SQ USE ../files/FDate.dat.Y2Z.srt    RECORD F,85 ORG SQ GIVE ../files/FDate.dat.Y2Z.mrg   RECORD F,85 ORG SQ    OPTION Y2PAST=70

export dd_infile=../files/FDate.dat.Y2T8.mrg
../bin/checkfdate                      
export dd_infile=../files/FDate.dat.Y2T4.mrg 
../bin/checkfdate                      
export dd_infile=../files/FDate.dat.Y2T2.mrg 
../bin/checkfdate                      
export dd_infile=../files/FDate.dat.Y2T3.mrg 
../bin/checkfdate                      
export dd_infile=../files/FDate.dat.Y2T5.mrg 
../bin/checkfdate                      
export dd_infile=../files/FDate.dat.Y2T6.mrg 
../bin/checkfdate                      
export dd_infile=../files/FDate.dat.Y4T7.mrg 
../bin/checkfdate
export dd_infile=../files/FDate.dat.Y2B.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2C.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2D.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2P.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2S.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2U.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2V.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2X.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2X.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2Y.mrg  
../bin/checkfdate                     
export dd_infile=../files/FDate.dat.Y2Z.mrg  
../bin/checkfdate
